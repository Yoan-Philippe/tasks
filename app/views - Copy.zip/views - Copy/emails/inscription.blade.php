<html>
	<body>
		<h1>Bonjour {{ $name }}</h1>
		<p>Merci de vous avoir inscrit à mon application, vous pouvez dès maintenant
			commencer à gérer vos tâches du quotidien de façon simple et efficace.</p>

		<p>Si vous rencontrez un problème lors de votre expérience avec mon application ou que vous voulez laisser un commentaire, vous pouvez à tout moment me contacter à l'adresse suivante : <a href="mailto:yoan.philippe@hotmail.com">yoan.philippe@hotmail.com</a></p>

		<p>Merci encore une fois et bonne journée.</p>
	</body>
</html>